package com.example.guardian_of_the_water

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DonationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation)
    }
}